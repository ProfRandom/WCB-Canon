1. **Mass** (m):  The total amount of matter present.
2. **Density** (ρ):  The *average* amount of matter per unit volume.
3. **Radius** (r):  The distance from the planemo’s center to its surface.
4. **Surface Gravity** (g):  The strength of gravitational acceleration at the planemo’s surface.
5. **Escape Velocity** (v): The minimum speed needed to completely escape the planemo’s gravity when starting from the surface.