Specific Tasks:
1. I have a formerly written section on stellar ages and planemo habitability that will also need reworking.
