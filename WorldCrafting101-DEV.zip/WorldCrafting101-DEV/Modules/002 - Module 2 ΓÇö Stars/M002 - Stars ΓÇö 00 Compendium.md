![[M002 - Stars — 01 Spectral Classes]]

---

![[M002 - Stars — 02 Parameters ✓]]

---

![[M002 - Stars — 03 The Nucleal Orbit ✓]]

---

![[M002 - Stars — 04 Thermozone Orbits ✓]]

---

![[M002 - Stars — 05 The Perannual Orbit ✓]]

---

![[M002 - Stars — 06 Relating the Nucleal and Perannual Orbits ✓]]

---

![[M002 - Stars — 07 Fine-tuning Stellar Parameters ✓]]

---

![[M002 - Stars — 08 `Sun-Like` Stars ✓]]