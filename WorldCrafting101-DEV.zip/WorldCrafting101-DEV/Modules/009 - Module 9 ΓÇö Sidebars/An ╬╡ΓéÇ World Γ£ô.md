
- If eccentricity is low (e < 0.10), no major seasonal variation through the year.
- All days are the same length, everywhere, all year long.
- "Seasonal" constellations still occur, because the direction the "night side" of the planemo faces still changes as it orbits.
- No change in the size of the star in the sky during orbit.
- From a stellar standpoint, the concept of a "year" would be meaningless
	- ONLY changes like the slow rotation of the night sky from night to night, or the period of a major moon would be available for calendrical development.

