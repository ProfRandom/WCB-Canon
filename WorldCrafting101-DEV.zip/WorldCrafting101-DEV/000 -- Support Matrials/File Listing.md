1. Master_Glossary_v1.19.md
2. Superhabitable Planemos ✓.md
3. Master_Glossary_v1.18.md
4. Master_Glossary_v1.17.md
5. Justifying Parahabitable Parameter Limits ✓.md
6. Setting The Stage ✓.md
7. Principle of Mass Measurement ✓.md
8. Planemo Equations of State ✓.md
9. Earth-like Planemos — What Does That Even Mean.md
10. Parameter Ranges By Spectral Class ✓.md
11. Main Sequence Stellar Equations of State ✓.md
12. An Extended Classification ✓.md
13. WBN Canonical -moic Ontotypes ✓.md
14. Stellamo Framework (Master Map) ✓.md
15. Planemo Framework (Master Map) ✓.md
16. Extended Geotic Habitability Guidelines ✓.md
17. Physical Properties of Planets ✓.md
18. Cryptolexicon.md
19. Ontosomic Expansion of "Life" Concepts ✓.md
20. Classification Rule — The Monobody Condition ✓.md
21. Xenotic Planemos ✓.md
22. Telluric Planemos ✓.md
23. Rheatic Planemos ✓.md
24. Stellar Thermal Interval Constant Table ✓.md
25. Standard Stellar Equations of State ✓.md
26. Gaean Planemos✓.md
27. Geotic Planemos ✓.md
28. Spectral Class Base Table ✓.md
29. Why Venus Isn't Gaean ✓.md
30. Albedo Estimates ✓.md
31. An ε₀ World ✓.md
32. Apparent Brightness ✓.md
33. Close-focus on Parameter Precedence ✓.md
34. Ellipse Parameters and Equations ✓.md
35. Equations for Worldbuilders ✓.md
36. Estimating Planetary Magnetospheres ✓.md
37. Geotic Ground States ✓.md
38. Habitable Zones Over Stellar Lifetimes ✓.md
39. Habitable Zones' of Giant Stars ✓.md
40. Justifying The Geotic and Gaean Parameter Envelopes ✓.md
41. Land-Water Balance and Hydrospheric Patterns ✓.md
42. Mind the Gap – The Shortcomings of the Traditional Spectral Scale ✓.md
43. Orbit Randomization ✓.md
44. Physical Properties of Planemos ✓.md
45. Planning A Detailed Atmosphere ✓.md
46. Range Constraints & Random Assignment ✓.md
47. Retrograde Rotation and Axial Tilt ✓.md
48. Stellar Lifetimes and System Habitability ✓.md
49. Stellar Magnitude and The Distance Modulus ✓.md
50. Stellar Populations ✓.md
51. The Anthropic Norm ✓.md
52. Units and Measures of Time ✓.md
53. M002 - Stars — 10 Folding In The Zones ✓.md
54. M002 - Stars — 01 Spectral Classes.md
55. M002 - Stars — 02 Parameters ✓.md
56. M002 - Stars — 03 The Nucleal Orbit ✓.md
57. M002 - Stars — 04 Thermozone Orbits ✓.md
58. M002 - Stars — 05 The Perannual Orbit ✓.md
59. M002 - Stars — 06 Relating the Nucleal and Perannual Orbits ✓.md
60. M002 - Stars — 07 Fine-tuning Stellar Parameters ✓.md
61. M002 - Stars — 08 `Sun-Like` Stars ✓.md
62. M002 - Stars — 09 Adding Orbits to the System ✓.md
63. 1.01 — Planemo Classes ✓.md
64. Introduction ✓.md