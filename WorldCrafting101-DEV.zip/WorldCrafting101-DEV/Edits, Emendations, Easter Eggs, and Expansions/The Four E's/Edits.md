# Edits Log (Canonical)

| Location             | Decision / Action                                              | Status  | Notes                 |
| -------------------- | -------------------------------------------------------------- | ------- | --------------------- |
| Geotic Planemos.md   | Fix typo: "Oceania" → "Oceanic"                                | ✓       | Typo                  |
| Rheatic Planemos.md  | Drop "vivamaximal" → replace with "highly conducive..."        | ⏳ To Do |                       |
| Terran Mass Scale.md | Clarify definition: upper bound = next interval – 1 demiterran | ⏳ To Do | tighten math phrasing |
