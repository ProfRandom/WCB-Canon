# Easter Eggs Log

| Location              | Joke / Gag Insert                                                                                                                  | Status  | Notes                         |
| --------------------- | ---------------------------------------------------------------------------------------------------------------------------------- | ------- | ----------------------------- |
| Monobody Ontotypes.md | Add aside: "...not to be confused with the excitable heymo"                                                                        | ⏳ To Do | Three Stooges joke            |
| Preface.md            | Add wink: "Expect the occasional playful aside (a heymo here, a marginal pun there...)"                                            | ⏳ To Do | Set the reader’s expectations |
| X.01...md             | The little Latin aside _sed ego dico fictiae_ is delightful — worth logging as a 3E item so it doesn’t get lost when editing tone. |         |                               |
